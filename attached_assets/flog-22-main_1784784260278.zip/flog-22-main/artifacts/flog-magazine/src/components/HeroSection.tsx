import { motion } from 'framer-motion';

export function HeroSection() {
  return (
    <section className="relative w-full h-[100dvh] flex flex-col justify-between overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-new.jpg"
          alt="FLOG Issue 1 Spring Cover - Cherry blossom street scene"
          className="w-full h-full object-cover object-center"
          loading="eager"
        />
        {/* Strong overlay so white text is always readable on bright images */}
        <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.42)' }} />
        <div className="absolute top-0 inset-x-0 h-60" style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.60) 0%, transparent 100%)' }} />
        <div className="absolute bottom-0 inset-x-0 h-60" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.60) 0%, transparent 100%)' }} />
      </div>

      {/* Top Grid Info — no animation delay so it's immediately visible */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full px-6 md:px-10 pt-28 flex justify-between font-sans text-[9px] md:text-[11px] font-bold tracking-[0.2em] uppercase"
        style={{ color: '#ffffff' }}
      >
        <div className="flex flex-col gap-1.5">
          <p>ISSUE NUMBER 1</p>
          <p>UNPACKED: FLOWER LOG MAGAZINE</p>
          <p>FLOG MAGAZINE</p>
        </div>
        <div className="flex flex-col gap-1.5 text-right">
          <p>THE FIRST ISSUE: CHERRY BLOSSOMS</p>
          <p>FIRST SEASON: SPRING</p>
          <p>YOUTH FLOWER</p>
        </div>
      </motion.div>

      {/* Massive Logotype — no delay, instant render */}
      <div className="relative z-10 w-full mt-auto flex flex-col">
        <div className="w-full text-center px-2 leading-[0.85] mb-4 md:mb-6">
          <h1
            className="font-display text-center mx-auto"
            style={{
              fontSize: 'clamp(7rem, 30vw, 38rem)',
              letterSpacing: '0.02em',
              color: '#ffffff',
              textShadow: '0 2px 16px rgba(0,0,0,0.45)',
            }}
          >
            FLOG
          </h1>
        </div>

        {/* Bottom Strip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="w-full flex justify-between items-center px-6 md:px-10 pb-6 md:pb-8 font-sans text-[9px] md:text-[11px] font-bold tracking-[0.2em] uppercase pt-4"
          style={{ color: '#ffffff', borderTop: '1px solid rgba(255,255,255,0.3)' }}
        >
          <p>20TH LIFE MAGAZINE</p>
          <p>WWW.FLOWERLOG20.COM</p>
        </motion.div>
      </div>
    </section>
  );
}
