import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Article } from '@/data/articles';

interface ArticleCardProps {
  article: Article;
  index: number;
  featured?: boolean;
}

export function ArticleCard({ article, index, featured = false }: ArticleCardProps) {
  const isLarge = featured;

  return (
    <motion.article 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className={`group cursor-pointer flex flex-col ${isLarge ? 'gap-6' : 'gap-4'} bg-card`}
    >
      <Link href={`/article/${article.slug}`} className="block overflow-hidden bg-muted aspect-[4/5] md:aspect-[3/4]">
        <img 
          src={article.imageUrl} 
          alt={article.title}
          loading={index > 2 ? "lazy" : "eager"}
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
      </Link>
      
      <div className="flex flex-col flex-1 px-1">
        <div className="flex items-center gap-3 mb-3">
          <Link 
            href={`/category/${article.category.slug}`}
            className="text-[10px] font-sans font-bold tracking-[0.2em] text-foreground uppercase border border-foreground/20 px-2 py-0.5 hover:bg-foreground hover:text-background hover:border-foreground transition-all"
          >
            {article.category.name}
          </Link>
          <span className="w-4 h-[1px] bg-border" />
          <span className="text-[10px] font-sans tracking-widest text-muted-foreground font-semibold uppercase">
            {article.author}
          </span>
        </div>

        <Link href={`/article/${article.slug}`} className="block group">
          <h3 className={`font-serif leading-tight text-foreground transition-colors group-hover:text-secondary ${isLarge ? 'text-3xl md:text-4xl mb-4' : 'text-xl mb-2'}`}>
            {article.title}
          </h3>
          <p className={`text-foreground/70 font-sans line-clamp-3 ${isLarge ? 'text-base md:text-lg leading-relaxed' : 'text-sm leading-relaxed'}`}>
            {article.excerpt}
          </p>
        </Link>
      </div>
    </motion.article>
  );
}
