import { Link, useLocation } from 'wouter';
import { CATEGORIES } from '@/data/articles';
import { Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <header 
      className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-border py-4"
    >
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-foreground p-1"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={24} />
          </button>

          {/* Logo & Sub-brand */}
          <div className="flex items-center gap-4">
            <Link href="/" className="font-display text-4xl md:text-5xl tracking-normal text-foreground leading-none z-50 pt-1">
              FLOG
            </Link>
            <span className="hidden lg:inline-block font-sans text-[10px] tracking-[0.2em] font-bold text-muted-foreground uppercase border-l border-border pl-4">
              FLOWER LOG MAGAZINE
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-8">
            {CATEGORIES.map((cat) => (
              <Link 
                key={cat.slug} 
                href={`/category/${cat.slug}`}
                className={`text-[11px] lg:text-xs font-sans tracking-[0.2em] uppercase transition-colors hover:text-secondary ${
                  location.startsWith(`/category/${cat.slug}`) 
                    ? 'text-foreground font-bold' 
                    : 'text-foreground/70 font-semibold'
                }`}
              >
                {cat.name}
              </Link>
            ))}
            <Link 
              href="/about"
              className={`text-[11px] lg:text-xs font-sans tracking-[0.2em] uppercase transition-colors hover:text-secondary ${
                location === '/about' ? 'text-foreground font-bold' : 'text-foreground/70 font-semibold'
              }`}
            >
              ABOUT
            </Link>
          </nav>

          {/* Issue Info */}
          <div className="hidden md:block text-[10px] font-sans font-bold text-foreground tracking-[0.2em] uppercase">
            ISSUE NO.2 — SUMMER
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 bg-white flex flex-col pt-20 px-6"
          >
            <button 
              className="absolute top-6 right-6 p-2 text-foreground"
              onClick={() => setMobileMenuOpen(false)}
              aria-label="Close menu"
            >
              <X size={28} />
            </button>
            
            <nav className="flex flex-col space-y-8 mt-12 text-center">
              {CATEGORIES.map((cat) => (
                <Link 
                  key={cat.slug} 
                  href={`/category/${cat.slug}`}
                  className="font-sans text-xl font-bold tracking-[0.2em] text-foreground uppercase"
                >
                  {cat.name}
                </Link>
              ))}
              <div className="h-px bg-border w-12 mx-auto my-4" />
              <Link 
                href="/about"
                className="font-sans text-xl font-bold tracking-[0.2em] text-foreground uppercase"
              >
                ABOUT FLOG
              </Link>
            </nav>
            
            <div className="mt-auto pb-12 text-center flex flex-col gap-2 text-xs font-sans font-bold text-muted-foreground tracking-[0.2em] uppercase">
              <span>FLOWER LOG MAGAZINE</span>
              <span>ISSUE NO.2 — SUMMER</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
