import { Link } from 'wouter';
import { CATEGORIES } from '@/data/articles';

export function Footer() {
  return (
    <footer className="bg-white border-t border-border py-16 md:py-24 mt-20">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-8">
          
          <div className="md:col-span-5">
            <h2 className="font-display text-6xl tracking-normal text-foreground leading-none mb-2">FLOG</h2>
            <p className="font-sans text-xs tracking-[0.2em] font-bold text-muted-foreground uppercase mb-6">
              FLOWER LOG MAGAZINE
            </p>
            <p className="text-foreground/70 text-sm max-w-sm leading-relaxed">
              가장 아름다운 순간에 만개하는 20대의 시간을 기록합니다.
              자연과 일상, 그리고 청춘을 담아내는 YOUTH FLOWER 라이프스타일 매거진.
            </p>
            <div className="mt-8 font-sans text-[10px] font-bold text-foreground tracking-[0.2em] uppercase">
              20th LIFE MAGAZINE · YOUTH FLOWER · www.flowerlog20.com
            </div>
          </div>

          <div className="md:col-span-2">
            <h3 className="font-sans text-[10px] font-bold tracking-[0.2em] text-foreground mb-6 uppercase">Categories</h3>
            <ul className="space-y-4">
              {CATEGORIES.map((cat) => (
                <li key={cat.slug}>
                  <Link 
                    href={`/category/${cat.slug}`}
                    className="text-sm font-sans text-foreground/70 hover:text-foreground font-semibold transition-colors"
                  >
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2">
            <h3 className="font-sans text-[10px] font-bold tracking-[0.2em] text-foreground mb-6 uppercase">Magazine</h3>
            <ul className="space-y-4 font-sans text-sm font-semibold">
              <li>
                <Link href="/about" className="text-foreground/70 hover:text-foreground transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <span className="text-foreground/40 cursor-not-allowed">Subscribe</span>
              </li>
              <li>
                <span className="text-foreground/40 cursor-not-allowed">Stockists</span>
              </li>
              <li>
                <span className="text-foreground/40 cursor-not-allowed">Contact</span>
              </li>
            </ul>
          </div>

          <div className="md:col-span-3">
            <h3 className="font-sans text-[10px] font-bold tracking-[0.2em] text-foreground mb-6 uppercase">Newsletter</h3>
            <p className="text-sm text-foreground/70 mb-4 font-sans">
              플로그 매거진의 새로운 소식을 받아보세요.
            </p>
            <form className="flex border-b border-border pb-2 focus-within:border-foreground transition-colors">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-transparent flex-1 text-sm outline-none placeholder:text-muted-foreground text-foreground"
              />
              <button type="submit" className="text-[10px] tracking-[0.2em] uppercase font-bold text-foreground hover:text-secondary transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="mt-20 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] text-muted-foreground font-sans font-bold tracking-[0.2em] uppercase">
            &copy; {new Date().getFullYear()} FLOG MAGAZINE. ALL RIGHTS RESERVED.
          </p>
          <div className="flex space-x-6 text-[10px] font-sans font-bold text-muted-foreground tracking-[0.2em] uppercase">
            <a href="#" className="hover:text-foreground transition-colors">INSTAGRAM</a>
            <a href="#" className="hover:text-foreground transition-colors">TWITTER</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
