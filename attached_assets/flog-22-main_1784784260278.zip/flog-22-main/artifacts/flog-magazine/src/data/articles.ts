export interface Article {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: {
    name: string;
    slug: string;
  };
  author: string;
  date: string;
  imageUrl: string;
  featured?: boolean;
}

export const CATEGORIES = [
  { name: '라이프', slug: 'life' },
  { name: '문화', slug: 'culture' },
  { name: '패션', slug: 'fashion' },
  { name: '피플', slug: 'people' },
  { name: '에디터스픽', slug: 'editors-pick' },
];

export const mockArticles: Article[] = [
  {
    id: '1',
    slug: 'the-first-season-spring',
    title: '벚꽃이 흩날리는 거리에서 발견한 첫 번째 청춘',
    excerpt: '가장 찬란하게 피어나고, 또 그만큼 빨리 지는 계절. 첫 번째 호에서는 벚꽃과 닮은 20대의 봄을 기록했다.',
    content: `
      <p>봄은 언제나 예고 없이 찾아와 우리를 들뜨게 한다. 서울의 거리는 어느새 연분홍빛으로 물들었고, 사람들의 옷차림은 한결 가벼워졌다.</p>
      <p>우리는 청춘이 꼭 이 벚꽃 같다고 생각했다. 가장 아름다운 순간에 만개하지만, 그 순간이 영원하지 않음을 알기에 더 소중한 시기. 한남동과 연남동의 골목길에서 마주친 수많은 '청춘의 꽃'들을 카메라에 담았다.</p>
      <h2>YOUTH FLOWER: 우리의 첫 번째 계절</h2>
      <p>가장 자연스러운 모습으로 거리를 걷는 사람들. 화려하게 꾸미지 않아도 뿜어져 나오는 생기. 플라워 로그 매거진(FLOWER LOG MAGAZINE)은 그 빛나는 찰나를 기록하기 위해 시작되었다.</p>
      <p>햇살이 좋은 날이면 테라스 카페에 앉아 좋아하는 책을 읽고, 선선한 저녁에는 한강공원을 산책하는 일상. 특별하지 않아서 더 특별한 우리의 20대 라이프스타일, 그 첫 번째 페이지를 연다.</p>
    `,
    category: { name: '라이프', slug: 'life' },
    author: '김서연 에디터',
    date: '2024.03.15',
    imageUrl: '/images/article-1.jpg',
    featured: true,
  },
  {
    id: '2',
    slug: 'second-issue-summer-beach',
    title: 'SUNNY BLOSSOME: 눈부신 여름 바다',
    excerpt: '뜨거운 태양 아래에서 더욱 선명해지는 색깔들. 두 번째 호, 우리의 여름이 시작되었다.',
    content: '<p>우리의 두 번째 계절은 바다를 향했다. 푸른 파도와 하얀 모래사장, 그리고 그 위를 걷는 우리의 발자국.</p><p>여름은 언제나 활기가 넘친다. 미니멀함을 잠시 벗어두고, 가장 밝고 경쾌한 색감으로 우리의 일상을 칠해볼 시간이다.</p>',
    category: { name: '문화', slug: 'culture' },
    author: '박도진 에디터',
    date: '2024.06.10',
    imageUrl: '/images/article-4.jpg',
  },
  {
    id: '3',
    slug: 'summer-outdoor-fashion',
    title: '햇살을 담은 서머 패션 에디토리얼',
    excerpt: '가벼운 린넨 셔츠, 찰랑이는 스커트. 햇살 아래에서 가장 자연스럽게 빛나는 서머 스타일링.',
    content: '<p>올여름은 조금 더 과감해져도 좋다. 파스텔 톤부터 비비드한 컬러까지, 여름만이 허락하는 색의 향연을 즐기자.</p>',
    category: { name: '패션', slug: 'fashion' },
    author: '이지우 에디터',
    date: '2024.06.05',
    imageUrl: '/images/article-3.jpg',
  },
  {
    id: '4',
    slug: 'sunny-cafe-terrace',
    title: '오후 3시의 테라스: 빛과 공간',
    excerpt: '따사로운 햇살이 스며드는 나만의 작은 아지트. 일상 속 여유를 만끽할 수 있는 볕 좋은 공간들.',
    content: '<p>창문을 활짝 열어두고 들어오는 바람을 맞으며 마시는 커피 한 잔. 그 평범하지만 소중한 시간들이 모여 우리의 삶을 채운다.</p>',
    category: { name: '라이프', slug: 'life' },
    author: '최현우 에디터',
    date: '2024.05.20',
    imageUrl: '/images/article-2.jpg',
  },
  {
    id: '5',
    slug: 'flower-log-nature',
    title: '일상 속의 자연: FLOWER LOG',
    excerpt: '책상 위 작은 화병, 퇴근길에 마주친 이름 모를 들꽃. 메마른 일상을 촉촉하게 적시는 자연의 기록.',
    content: '<p>플라워 로그라는 이름에 걸맞게, 우리는 늘 일상 속 꽃과 식물에 주목한다. 자연이 주는 긍정적인 에너지는 어떤 화려한 물건으로도 대체할 수 없다.</p>',
    category: { name: '피플', slug: 'people' },
    author: '김서연 에디터',
    date: '2024.05.10',
    imageUrl: '/images/article-5.jpg',
  },
];
