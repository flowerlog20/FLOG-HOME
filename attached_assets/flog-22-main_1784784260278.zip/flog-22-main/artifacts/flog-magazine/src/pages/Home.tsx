import { Helmet } from 'react-helmet-async';
import { HeroSection } from '@/components/HeroSection';
import { ArticleCard } from '@/components/ArticleCard';
import { mockArticles } from '@/data/articles';
import { Link } from 'wouter';

export default function Home() {
  const featuredArticle = mockArticles.find(a => a.featured) || mockArticles[0];
  const gridArticles = mockArticles.filter(a => a.id !== featuredArticle.id).slice(0, 4);

  return (
    <>
      <Helmet>
        <title>FLOG - FLOWER LOG MAGAZINE | 홈</title>
        <meta name="description" content="플라워 로그(FLOG) 매거진: 가장 아름다운 순간에 만개하는 20대의 라이프스타일, 그 두 번째 시즌 SUMMER." />
      </Helmet>

      <main className="w-full flex flex-col min-h-screen">
        <HeroSection />

        {/* Featured Section */}
        <section className="py-24 md:py-32 container mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-16 flex items-center justify-between border-b border-border pb-6">
            <h2 className="font-display text-4xl md:text-5xl tracking-normal text-foreground">FEATURED</h2>
            <div className="hidden md:flex gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-border"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-border"></span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-start">
            <div className="lg:col-span-7">
              <ArticleCard article={featuredArticle} index={0} featured={true} />
            </div>
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-8">
              {gridArticles.slice(0, 2).map((article, index) => (
                <ArticleCard key={article.id} article={article} index={index + 1} />
              ))}
            </div>
          </div>
        </section>

        {/* Editorial Highlight Strip */}
        <section className="bg-foreground text-background py-32 mt-12 relative overflow-hidden">
          <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10 text-center">
            <h2 className="font-serif text-4xl md:text-6xl lg:text-7xl font-medium tracking-tighter mb-8 text-background/90 max-w-4xl mx-auto leading-tight">
              "뜨거운 태양 아래에서 <br className="hidden md:block"/>더욱 선명해지는 청춘의 색깔들."
            </h2>
            <p className="font-sans text-background/60 tracking-[0.2em] font-bold text-sm uppercase mb-12">
              THE SECOND ISSUE: SUNNY BLOSSOME
            </p>
            <Link href="/article/second-issue-summer-beach" className="inline-flex items-center justify-center border border-background/30 px-8 py-4 text-[11px] font-bold tracking-[0.2em] uppercase hover:bg-background hover:text-foreground transition-colors">
              스토리 읽기
            </Link>
          </div>
        </section>

        {/* Latest Articles */}
        <section className="py-24 md:py-32 container mx-auto px-4 md:px-6 lg:px-8">
          <div className="mb-16 border-b border-border pb-6">
            <h2 className="font-display text-4xl md:text-5xl tracking-normal text-foreground">LATEST</h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
            {mockArticles.slice().reverse().map((article, index) => (
              <ArticleCard key={article.id} article={article} index={index} />
            ))}
          </div>
        </section>

      </main>
    </>
  );
}
