import { Link } from "wouter";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex w-full flex-col items-center justify-center min-h-[70vh] bg-background text-foreground">
      <div className="flex items-center space-x-4 mb-8">
        <AlertCircle className="h-10 w-10 text-secondary" />
        <h1 className="text-4xl font-serif font-bold">404</h1>
      </div>
      <p className="text-muted-foreground font-sans mb-8">존재하지 않는 페이지입니다.</p>
      <Link href="/" className="px-6 py-3 border border-border hover:bg-foreground hover:text-background transition-colors font-sans text-sm tracking-widest uppercase">
        홈으로 돌아가기
      </Link>
    </div>
  );
}
