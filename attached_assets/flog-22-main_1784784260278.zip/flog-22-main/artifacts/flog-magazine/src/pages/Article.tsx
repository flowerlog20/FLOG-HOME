import { useRoute } from 'wouter';
import { Helmet } from 'react-helmet-async';
import { mockArticles } from '@/data/articles';
import { motion, useScroll, useSpring } from 'framer-motion';
import { Link } from 'wouter';

export default function Article() {
  const [, params] = useRoute('/article/:slug');
  const slug = params?.slug;
  const article = mockArticles.find(a => a.slug === slug);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  if (!article) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center pt-24">
        <h1 className="font-display text-4xl mb-4">Article not found</h1>
        <Link href="/" className="text-secondary hover:underline underline-offset-4 font-sans font-bold">Return home</Link>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{article.title} - FLOWER LOG MAGAZINE</title>
        <meta name="description" content={article.excerpt} />
        <meta property="og:title" content={`${article.title} - FLOG`} />
        <meta property="og:description" content={article.excerpt} />
        <meta property="og:image" content={article.imageUrl} />
      </Helmet>

      {/* Progress Bar */}
      <motion.div 
        className="fixed top-[64px] md:top-[72px] left-0 right-0 h-[2px] bg-secondary origin-left z-[40]"
        style={{ scaleX }}
      />

      <article className="pt-32 pb-32">
        {/* Article Header */}
        <header className="container mx-auto px-4 md:px-6 lg:px-8 pt-8 md:pt-12 pb-16 max-w-4xl text-center">
          <Link 
            href={`/category/${article.category.slug}`}
            className="inline-block mb-8 text-[10px] font-sans font-bold tracking-[0.2em] text-foreground uppercase border border-foreground/20 px-3 py-1 hover:bg-foreground hover:text-background transition-colors"
          >
            {article.category.name}
          </Link>
          
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground font-medium leading-[1.2] tracking-tight mb-8">
            {article.title}
          </h1>
          
          <p className="text-lg md:text-xl text-foreground/70 font-sans max-w-2xl mx-auto leading-relaxed mb-12">
            {article.excerpt}
          </p>

          <div className="flex items-center justify-center gap-4 text-[10px] font-sans font-bold tracking-[0.2em] text-muted-foreground uppercase border-t border-border pt-8 max-w-md mx-auto">
            <span>By {article.author}</span>
            <span className="w-1 h-1 bg-border rounded-full" />
            <time>{article.date}</time>
          </div>
        </header>

        {/* Hero Image */}
        <div className="w-full max-w-6xl mx-auto px-4 md:px-6 lg:px-8 mb-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="aspect-[16/9] overflow-hidden bg-muted"
          >
            <img 
              src={article.imageUrl} 
              alt={article.title} 
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>

        {/* Article Content */}
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-3xl">
          <div 
            className="prose prose-lg md:prose-xl prose-stone max-w-none
                       prose-headings:font-serif prose-headings:font-medium prose-headings:tracking-tight
                       prose-p:font-sans prose-p:leading-relaxed prose-p:text-foreground/80
                       prose-a:text-secondary prose-a:underline-offset-4 hover:prose-a:text-foreground transition-colors
                       first-letter:text-7xl first-letter:font-display first-letter:text-secondary first-letter:mr-3 first-letter:float-left first-letter:leading-none"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Social Share (Static) */}
          <div className="mt-20 pt-8 border-t border-border flex items-center justify-between">
            <span className="text-[10px] font-sans font-bold tracking-[0.2em] uppercase text-foreground">Share this story</span>
            <div className="flex gap-6 font-sans text-[10px] font-bold tracking-[0.2em] uppercase text-muted-foreground">
              <button className="hover:text-foreground transition-colors">Twitter</button>
              <button className="hover:text-foreground transition-colors">Facebook</button>
              <button className="hover:text-foreground transition-colors">Copy Link</button>
            </div>
          </div>
        </div>
      </article>
    </>
  );
}
