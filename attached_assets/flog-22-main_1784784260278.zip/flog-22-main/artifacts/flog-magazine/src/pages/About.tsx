import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

export default function About() {
  return (
    <>
      <Helmet>
        <title>About FLOG | FLOWER LOG MAGAZINE</title>
        <meta name="description" content="YOUTH FLOWER: 20대의 가장 찬란한 순간을 기록하는 라이프스타일 매거진, 플라워 로그." />
      </Helmet>

      <main className="w-full min-h-screen pt-32 pb-24 bg-background">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-5xl">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24 items-center mb-32">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="font-display text-7xl md:text-9xl tracking-normal text-foreground leading-none mb-6">
                FLOG
              </h1>
              <p className="font-sans text-xs tracking-[0.2em] font-bold text-muted-foreground uppercase mb-8">
                UNPACKED: FLOWER LOG MAGAZINE
              </p>
              <p className="text-2xl md:text-3xl font-serif leading-relaxed text-foreground mb-6">
                "가장 아름다운 순간에 만개하는<br/>우리의 20대를 기록하다."
              </p>
              <p className="font-sans text-foreground/70 leading-relaxed max-w-md">
                플라워 로그(FLOWER LOG) 매거진은 마치 활짝 피어난 꽃처럼 가장 생기 넘치고 눈부신 20대의 라이프스타일을 담아냅니다. 자연스럽고 경쾌하며, 조금은 서툴더라도 눈부시게 빛나는 청춘(YOUTH FLOWER)의 모든 순간을 한 권의 기록으로 엮습니다.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="aspect-[3/4] bg-muted relative"
            >
              <img 
                src="/images/hero-new.jpg" 
                alt="FLOG Lifestyle" 
                className="w-full h-full object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 border border-border hidden md:block">
                <p className="font-sans text-[10px] font-bold tracking-[0.2em] uppercase">20th LIFE MAGAZINE<br/>FOUNDED IN SEOUL, 2024</p>
              </div>
            </motion.div>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="border-t border-border pt-20"
          >
            <h2 className="font-display text-4xl mb-12">YOUTH FLOWER MANIFESTO</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 font-sans text-foreground/80 leading-relaxed">
              <div>
                <span className="text-secondary font-display text-3xl block mb-4">01</span>
                <h3 className="font-bold text-lg mb-3">빛나는 계절의 기록</h3>
                <p>봄의 벚꽃, 여름의 파도. 빠르게 지나가는 계절처럼 순식간에 흘러가는 20대의 눈부신 찰나를 다채롭고 선명한 색채로 포착합니다.</p>
              </div>
              <div>
                <span className="text-secondary font-display text-3xl block mb-4">02</span>
                <h3 className="font-bold text-lg mb-3">자연스러운 아름다움</h3>
                <p>꾸며낸 화려함보다 일상 속 자연스러운 빛을 사랑합니다. 밝고 긍정적인 에너지, 그 자체로 온전한 청춘의 모습을 지지합니다.</p>
              </div>
              <div>
                <span className="text-secondary font-display text-3xl block mb-4">03</span>
                <h3 className="font-bold text-lg mb-3">새로운 라이프스타일</h3>
                <p>어디로든 떠나고 무엇이든 시도할 수 있는 자유로움. 우리만의 취향을 담은 아웃도어 라이프스타일과 문화를 소개합니다.</p>
              </div>
            </div>
          </motion.div>

          <div className="mt-32 text-center pb-20 border-b border-border">
            <p className="font-sans text-[10px] font-bold tracking-[0.2em] text-muted-foreground uppercase mb-4">www.flowerlog20.com</p>
            <a href="mailto:hello@flowerlog20.com" className="font-display text-5xl hover:text-secondary transition-colors underline underline-offset-8">
              hello@flowerlog20.com
            </a>
          </div>

        </div>
      </main>
    </>
  );
}
