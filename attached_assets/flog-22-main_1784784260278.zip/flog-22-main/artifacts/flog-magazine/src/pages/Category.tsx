import { useRoute } from 'wouter';
import { Helmet } from 'react-helmet-async';
import { mockArticles, CATEGORIES } from '@/data/articles';
import { ArticleCard } from '@/components/ArticleCard';
import { Link } from 'wouter';

export default function Category() {
  const [, params] = useRoute('/category/:name');
  const categorySlug = params?.name;
  
  const category = CATEGORIES.find(c => c.slug === categorySlug);
  const articles = mockArticles.filter(a => a.category.slug === categorySlug);

  if (!category) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center">
        <h1 className="font-serif text-3xl mb-4">Category not found</h1>
        <Link href="/" className="text-secondary hover:underline underline-offset-4">Return home</Link>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{category.name} | FLOWER LOG MAGAZINE</title>
        <meta name="description" content={`FLOG 매거진 ${category.name} 카테고리의 최신 아티클을 확인하세요.`} />
      </Helmet>

      <main className="w-full min-h-screen pt-40 pb-24 bg-background">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          
          <header className="mb-20 text-center">
            <span className="text-[10px] font-sans font-bold tracking-[0.2em] text-muted-foreground uppercase mb-4 block">
              Category
            </span>
            <h1 className="font-display text-6xl md:text-8xl tracking-normal text-foreground mb-6">
              {category.name}
            </h1>
            <p className="text-foreground/70 font-sans max-w-xl mx-auto font-semibold">
              FLOWER LOG 매거진이 주목한 동시대의 {category.name} 이야기.
            </p>
          </header>

          {articles.length > 0 ? (
            <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8 pb-20">
              {articles.map((article, index) => (
                <div key={article.id} className="break-inside-avoid">
                  <ArticleCard article={article} index={index} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-32 border-y border-border">
              <p className="text-muted-foreground font-sans text-lg">이 카테고리에 아직 발행된 기사가 없습니다.</p>
            </div>
          )}
          
        </div>
      </main>
    </>
  );
}
